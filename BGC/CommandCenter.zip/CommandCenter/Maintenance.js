document.addEventListener('DOMContentLoaded', function () {
    fetchBusData();
});

function fetchBusData() {
    // Example data; replace with actual data fetching logic
    const buses = [
        { id: 'Bus01', model: 'Model X', lastMaintenance: '2023-09-15', status: 'Operational' },
        { id: 'Bus02', model: 'Model Y', lastMaintenance: '2023-08-20', status: 'Under Maintenance' },
        // Add more bus entries as needed
    ];

    const tableBody = document.querySelector('#busTable tbody');
    tableBody.innerHTML = ''; // Clear existing rows

    buses.forEach(bus => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${bus.id}</td>
            <td>${bus.model}</td>
            <td>${bus.lastMaintenance}</td>
            <td>${bus.status}</td>
        `;
        row.addEventListener('click', () => {
            window.location.href = `busDetails.html?busId=${bus.id}`;
        });
        tableBody.appendChild(row);
    });
}