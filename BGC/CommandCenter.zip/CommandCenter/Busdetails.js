document.addEventListener('DOMContentLoaded', function () {
    const urlParams = new URLSearchParams(window.location.search);
    const busId = urlParams.get('busId');
    fetchBusDetails(busId);
});

function fetchBusDetails(busId) {
    // Example data; replace with actual data fetching logic
    const busDetails = {
        'Bus01': {
            number: 'Bus01',
            plateNumber: 'XYZ-1234',
            chassisNumber: 'CH1234567890',
            engineNumber: 'EN9876543210',
            seatingCapacity: 50,
            fuelType: 'Diesel',
            nextScheduledMaintenance: '2023-12-01',
            tireReplacementDate: '2023-06-15',
            batteryReplacementDate: '2023-07-20',
            brakeCheckDate: '2023-08-10',
            currentDriver: 'John Doe',
            dailyUsage: '200 km',
            currentStatus: 'Operational',
            fuelEfficiency: '8 km/l',
            safetyInspectionDate: '2023-09-05',
            accidentHistory: 'No accidents reported.',
            emergencyEquipment: 'Fire extinguisher, First aid kit',
            registrationExpiry: '2024-01-15',
            insuranceDetails: 'Policy #123456, Expires 2024-01-15',
            emissionsCompliance: 'Compliant with Euro 6 standards'
        },
        // Add more bus details as needed
    };

    const bus = busDetails[busId];
    if (bus) {
        const detailsDiv = document.getElementById('Busdetails');
        detailsDiv.innerHTML = `
            <h2>Bus Number: ${bus.number}</h2>
            <div class="detail-item"><span>Plate Number:</span> <span>${bus.plateNumber}</span></div>
            <div class="detail-item"><span>Chassis Number:</span> <span>${bus.chassisNumber}</span></div>
            <div class="detail-item"><span>Engine Number:</span> <span>${bus.engineNumber}</span></div>
            <div class="detail-item"><span>Seating Capacity:</span> <span>${bus.seatingCapacity}</span></div>
            <div class="detail-item"><span>Fuel Type:</span> <span>${bus.fuelType}</span></div>
            <div class="detail-item"><span>Next Scheduled Maintenance:</span> <span>${bus.nextScheduledMaintenance}</span></div>
            <div class="detail-item"><span>Tire Replacement Date:</span> <span>${bus.tireReplacementDate}</span></div>
            <div class="detail-item"><span>Battery Replacement Date:</span> <span>${bus.batteryReplacementDate}</span></div>
            <div class="detail-item"><span>Brake Check Date:</span> <span>${bus.brakeCheckDate}</span></div>
            <div class="detail-item"><span>Current Driver:</span> <span>${bus.currentDriver}</span></div>
            <div class="detail-item"><span>Daily Usage:</span> <span>${bus.dailyUsage}</span></div>
            <div class="detail-item"><span>Current Status:</span> <span>${bus.currentStatus}</span></div>
            <div class="detail-item"><span>Fuel Efficiency:</span> <span>${bus.fuelEfficiency}</span></div>
            <div class="detail-item"><span>Safety Inspection Date:</span> <span>${bus.safetyInspectionDate}</span></div>
            <div class="detail-item"><span>Accident History:</span> <span>${bus.accidentHistory}</span></div>
            <div class="detail-item"><span>Emergency Equipment:</span> <span>${bus.emergencyEquipment}</span></div>
            <div class="detail-item"><span>Registration Expiry:</span> <span>${bus.registrationExpiry}</span></div>
            <div class="detail-item"><span>Insurance Details:</span> <span>${bus.insuranceDetails}</span></div>
            <div class="detail-item"><span>Emissions Compliance:</span> <span>${bus.emissionsCompliance}</span></div>
        `;
    } else {
        alert('Bus details not found.');
    }
}
