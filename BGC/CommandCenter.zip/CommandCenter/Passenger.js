document.addEventListener('DOMContentLoaded', function () {
    const routePassengerCounts = [
        { route: 'Route 1', current: 30, totalToday: 120, totalOverall: 5000 },
        { route: 'Route 2', current: 25, totalToday: 100, totalOverall: 4500 },
        // Add more routes as needed
    ];

    const busPassengerList = [
        { busNumber: 'Bus01', passengers: ['Alice', 'Bob', 'Charlie'] },
        { busNumber: 'Bus02', passengers: ['David', 'Eve'] },
        // Add more buses as needed
    ];

    populateRoutePassengerCounts(routePassengerCounts);
    populateBusPassengerList(busPassengerList);
});

function populateRoutePassengerCounts(data) {
    const tbody = document.querySelector('#routePassengerCounts tbody');
    tbody.innerHTML = data.map(route => `
        <tr>
            <td>${route.route}</td>
            <td>${route.current}</td>
            <td>${route.totalToday}</td>
            <td>${route.totalOverall}</td>
        </tr>
    `).join('');
}

function populateBusPassengerList(data) {
    const container = document.getElementById('busPassengerList');
    container.innerHTML = data.map(bus => `
        <div>
            <h3>Bus Number: ${bus.busNumber}</h3>
            <ul>
                ${bus.passengers.map(passenger => `<li>${passenger}</li>`).join('')}
            </ul>
        </div>
    `).join('');
}